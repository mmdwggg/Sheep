﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel = new System.Windows.Forms.Panel();
            this.Btn_back = new System.Windows.Forms.Button();
            this.Btn_refresh = new System.Windows.Forms.Button();
            this.Timer_clock = new System.Windows.Forms.Timer(this.components);
            this.Label_clock = new System.Windows.Forms.Label();
            this.Btn_withdraw = new System.Windows.Forms.Button();
            this.Pic_music = new System.Windows.Forms.PictureBox();
            this.Timer_move = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Pic_music)).BeginInit();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.Transparent;
            this.panel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel.BackgroundImage")));
            this.panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel.Location = new System.Drawing.Point(205, 723);
            this.panel.Name = "panel";
            this.panel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panel.Size = new System.Drawing.Size(503, 73);
            this.panel.TabIndex = 0;
            // 
            // Btn_back
            // 
            this.Btn_back.BackColor = System.Drawing.Color.Transparent;
            this.Btn_back.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_back.BackgroundImage")));
            this.Btn_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_back.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_back.Location = new System.Drawing.Point(0, 0);
            this.Btn_back.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Btn_back.Name = "Btn_back";
            this.Btn_back.Size = new System.Drawing.Size(39, 40);
            this.Btn_back.TabIndex = 1;
            this.Btn_back.UseVisualStyleBackColor = false;
            this.Btn_back.Click += new System.EventHandler(this.Btnback_Click);
            // 
            // Btn_refresh
            // 
            this.Btn_refresh.BackColor = System.Drawing.Color.Transparent;
            this.Btn_refresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_refresh.BackgroundImage")));
            this.Btn_refresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_refresh.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_refresh.Location = new System.Drawing.Point(653, 668);
            this.Btn_refresh.Name = "Btn_refresh";
            this.Btn_refresh.Size = new System.Drawing.Size(55, 48);
            this.Btn_refresh.TabIndex = 2;
            this.Btn_refresh.UseVisualStyleBackColor = false;
            this.Btn_refresh.Click += new System.EventHandler(this.Refresh);
            // 
            // Timer_clock
            // 
            this.Timer_clock.Interval = 1000;
            this.Timer_clock.Tick += new System.EventHandler(this.Timerclock_Tick);
            // 
            // Label_clock
            // 
            this.Label_clock.BackColor = System.Drawing.Color.Transparent;
            this.Label_clock.Location = new System.Drawing.Point(354, 0);
            this.Label_clock.Name = "Label_clock";
            this.Label_clock.Size = new System.Drawing.Size(161, 40);
            this.Label_clock.TabIndex = 3;
            this.Label_clock.Text = "用时";
            // 
            // Btn_withdraw
            // 
            this.Btn_withdraw.BackColor = System.Drawing.Color.Transparent;
            this.Btn_withdraw.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_withdraw.BackgroundImage")));
            this.Btn_withdraw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_withdraw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_withdraw.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_withdraw.Location = new System.Drawing.Point(205, 668);
            this.Btn_withdraw.Name = "Btn_withdraw";
            this.Btn_withdraw.Size = new System.Drawing.Size(52, 49);
            this.Btn_withdraw.TabIndex = 4;
            this.Btn_withdraw.UseVisualStyleBackColor = false;
            this.Btn_withdraw.Click += new System.EventHandler(this.Withdraw);
            // 
            // Pic_music
            // 
            this.Pic_music.BackColor = System.Drawing.Color.Transparent;
            this.Pic_music.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.bofang;
            this.Pic_music.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pic_music.Location = new System.Drawing.Point(851, 2);
            this.Pic_music.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Pic_music.Name = "Pic_music";
            this.Pic_music.Size = new System.Drawing.Size(47, 38);
            this.Pic_music.TabIndex = 5;
            this.Pic_music.TabStop = false;
            this.Pic_music.Click += new System.EventHandler(this.Picmusic_Click);
            // 
            // Timer_move
            // 
            this.Timer_move.Interval = 50;
            this.Timer_move.Tick += new System.EventHandler(this.Timermove_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(910, 844);
            this.Controls.Add(this.Pic_music);
            this.Controls.Add(this.Btn_withdraw);
            this.Controls.Add(this.Label_clock);
            this.Controls.Add(this.Btn_refresh);
            this.Controls.Add(this.Btn_back);
            this.Controls.Add(this.panel);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Pic_music)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Button Btn_back;
        private System.Windows.Forms.Button Btn_refresh;
        private System.Windows.Forms.Timer Timer_clock;
        private System.Windows.Forms.Label Label_clock;
        private System.Windows.Forms.Button Btn_withdraw;
        private System.Windows.Forms.PictureBox Pic_music;
        private System.Windows.Forms.Timer Timer_move;
    }
}

