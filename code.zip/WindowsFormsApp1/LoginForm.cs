﻿using System;
using System.Media;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LoginForm : Form
    {
        SoundPlayer player = new SoundPlayer();//音乐播放
        Random random = new Random();//随机数发生器对象

        public int DifficultyLevel { get; set; }//难度

        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            
        }


        private void btnEasy_Click(object sender, EventArgs e)
        {

            ChooseDifficulty(1);
        }

        private void btnMedium_Click(object sender, EventArgs e)
        {

            ChooseDifficulty(3); 
        }

        private void btnDifficult_Click(object sender, EventArgs e)
        {

            ChooseDifficulty(6); 
        }
        private void ChooseDifficulty(int DifficultyLevel)
        {
            this.DifficultyLevel = DifficultyLevel;
            Form1 form1 = new Form1(this);
            form1.DifficultyLevel = DifficultyLevel; // 将 DifficultyLevel 的值传递给 Form1

            form1.Show();
            // 最小化窗体
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
