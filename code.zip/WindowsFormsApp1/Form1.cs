﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        class Pic
        {
            public Bitmap bitmap;
            public int index;
        }
        class LastPic
        {
            public Point Loc;   
            public bool IsAddedToPanel;
        } 

        class MovePic
        {
            public int count;
            public Button btn;
            public int DistanceX;//X距离
            public int DistanceY;//Y距离
        }
        private MovePic movePic = null;


        double t = 0.1;

        private LastPic lastClickedImageInfo = null;//记录上一次点击的图片的 ImageInfo 对象

        private int ElapsedSeconds = 0;//记录时间

        static Form ClientFormSet;//定义一个静态窗口变量去存储主窗口，方便调用

        public int RefreshNum = 0;//刷新次数

        public int WithdrawNum = 0;//撤回次数

        public int PicCount = 0;//图片数量

        public int DifficultyLevel;//难度

        public int OffsetX;//图片水平偏移量

        public int OffsetY;//图片垂直偏移量

        private int ClickedPicCount = 0;//已经点击的图片数量

        private List<Image> PicBackgrounds = new List<Image>(); // 存储预加载的图片背景图片

        private SoundPlayer clickSound; // 声明音效播放器

        private string egm = "bgm\\Genshin Impact.wav";//定义变量来存储音频路径

        SoundPlayer bgm;


        public Form1(Form clientForm)
        {
            InitializeComponent();
            ClientFormSet = clientForm;//用刚刚定义的静态变量存储大窗口
            this.DoubleBuffered = true;//双缓冲减少画面闪烁
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);//双缓冲
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);//绘制整个表面
            this.SetStyle(ControlStyles.UserPaint, true);//开发者绘制表面

            bgm = new SoundPlayer(egm);//控制声音播放
            bgm.PlayLooping();

            ClientFormSet = clientForm;
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);

            clickSound = new SoundPlayer("bgm\\点击消除音效_爱给网_aigei_com.wav"); // 音效文件路径
            bgm = new SoundPlayer(egm);
            bgm.PlayLooping();
        }
        Random random = new Random();



        private void ChoosePic()//选取图片
        {
            int Num = DifficultyLevel * 3;
            for (int i = 0; i < Num; i++)
            {
                string imageFileName = "图片素材\\" + i + ".jpg";
                Image image = Image.FromFile(imageFileName);
                PicBackgrounds.Add(image);
            }
        }
        private void Move()
        {
            movePic.count = panel.Controls.Count;
            movePic.DistanceX = movePic.btn.Location.X - new Point(panel.Location.X+(movePic.count % 7) * 52, panel.Location.Y).X;
            movePic.DistanceY = movePic.btn.Location.Y - new Point(panel.Location.X + (movePic.count % 7) * 52, panel.Location.Y).Y;
            movePic.btn.BringToFront();
            Timer_move.Start();
        }

        private void AddPic(Button button)
        {
            int sameImageCount = 0; // 相同图片的数量
            List<Button> sameImageButtons = new List<Button>(); // 存储相同图片的 Button
            int count = panel.Controls.Count;//获取已有图片数量

            // 获取当前按钮的图片
            Bitmap currentImage = new Bitmap(button.Image);

            // 遍历 panel 中的 Button
            for (int i = count - 1; i >= 0; i--)
            {
                Button existButton = panel.Controls[i] as Button;

                if (existButton != null)
                {
                    // 判断两张图片是否一致
                    Bitmap existImage = new Bitmap(existButton.Image);

                    if (EqualImages(currentImage, existImage))
                    {
                        sameImageCount++;
                        sameImageButtons.Add(existButton);
                    }
                }
            }


            if (sameImageCount >= 2)
            {
                // 将当前按钮添加到相同图片的按钮列表中
                sameImageButtons.Add(button);
                //进行三消
                foreach (Button sameImageButton in sameImageButtons)
                {
                    panel.Controls.Remove(sameImageButton);
                }
                sameImageButtons.Clear();

                // 对 panel 中的 Button 进行重新排序
                for (int j = 0; j < panel.Controls.Count; j++)
                {
                    Button panelButton = panel.Controls[j] as Button;
                    if (panelButton != null)
                    {
                        panelButton.Location = new Point((j % 7) * 52, 0);
                    }
                }
                lastClickedImageInfo.IsAddedToPanel = false;
                return;
            }
            button.Click -= new EventHandler(Button_Click);
            if (!panel.Controls.Contains(button))
            {
                panel.Controls.Add(button);
                button.Location = new Point((count % 7) * 52, 0);
            }
            if (panel.Controls.Count >= 7)
            {
                Timer_clock.Stop();
                MessageBox.Show("槽已满，游戏结束！");
                ClientFormSet.WindowState = FormWindowState.Normal;
                this.Close();
            }
            return;
        }

        //比较两张图片是否为同一张
        private bool EqualImages(Bitmap image1, Bitmap image2)
        {
            //比较大小是否相同
            if (image1.Width != image2.Width || image1.Height != image2.Height)
            {
                return false;
            }
            //比较每个像素点是否相同
            for (int x = 0; x < image1.Width; x++)
            {
                for (int y = 0; y < image1.Height; y++)
                {
                    if (image1.GetPixel(x, y) != image2.GetPixel(x, y))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        //获取一个图片实例
        public Bitmap GetBitmap()//Bitmap 类是 Image 类的一个具体实现，
                                 //它表示一个由像素组成的图像。
                                 //相比之下，Image 类则是一个抽象类，
        {
            int imageIndex = random.Next(0, PicBackgrounds.Count);
            //获取图片
            Image image = PicBackgrounds[imageIndex];

            Bitmap buttonBackground = new Bitmap(image);

            return buttonBackground;
        }
        public Bitmap GetEBitmap(int imageIndex)
        {
            //获取图片
            Image image = PicBackgrounds[imageIndex];

            Bitmap buttonBackground = new Bitmap(image);

            return buttonBackground;
        }

        //比较所以图像间谁更靠上谁和谁有重叠
        private void Overlap()
        {
            foreach (Button btn in this.Controls.OfType<Button>())
            {
                btn.Enabled = true;
            }

            foreach (Button btn1 in this.Controls.OfType<Button>())
            {
                foreach (Button btn2 in this.Controls.OfType<Button>())
                {
                    //Tab小的图片会更靠上
                    if (btn1.TabIndex > btn2.TabIndex)
                    {
                        // 检查是否有重叠
                        Rectangle rect1 = new Rectangle(btn1.Location, btn1.Size);
                        Rectangle rect2 = new Rectangle(btn2.Location, btn2.Size);
                        if (rect1.IntersectsWith(rect2))
                        {
                            // 比较 TabIndex
                            btn1.Enabled = false;
                            break;
                        }
                    }
                }
            }
        }
        private void Refresh(object sender, EventArgs e)
        {
            int centerX, centerY;
            if (DifficultyLevel == 1)
            {
                centerX = this.ClientSize.Width / 2;
                centerY = this.ClientSize.Height / 2;
            }
            else if (DifficultyLevel == 3)
            {
                centerX = this.ClientSize.Width / 2;
                centerY = this.ClientSize.Height / 2;
            }
            else
            {
                centerX = this.ClientSize.Width / 2;
                centerY = this.ClientSize.Height / 2;
            }
            foreach (Button button in this.Controls.OfType<Button>())
            {
                if (button.Image != null&&button.Text!="刷新"&& button.Text != "返回")
                {
                    int offsetX = random.Next(-250, 250);
                    int offsetY = random.Next(-300, 150);
                    button.Location = new Point(centerX + offsetX, centerY + offsetY);
                }
            }
            RefreshNum++;
            Overlap();
        }
        private void Withdraw(object sender, EventArgs e)
        {
            if (lastClickedImageInfo != null)
            {
                if (lastClickedImageInfo.IsAddedToPanel)
                {
                    int count = panel.Controls.Count;
                    Button LastButton = panel.Controls[count - 1] as Button;
                    this.Controls.Add(LastButton);
                    LastButton.BringToFront();
                    panel.Controls.Remove(LastButton);
                    LastButton.Location = lastClickedImageInfo.Loc;
                    ClickedPicCount--;
                    LastButton.Click += new EventHandler(Button_Click);
                    Overlap();
                    WithdrawNum++;
                }
                lastClickedImageInfo = null;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Timer_clock.Start();

            //获取图片
            ChoosePic();

            // 确定窗体的中心坐标
            int centerX, centerY;
            if (DifficultyLevel == 1)
            {
                centerX = this.ClientSize.Width / 3;
                centerY = this.ClientSize.Height / 3;
            }
            else if (DifficultyLevel == 3)
            {
                centerX = this.ClientSize.Width / 4;
                centerY = this.ClientSize.Height / 4;
            }
            else
            {
                centerX = this.ClientSize.Width / 7;
                centerY = this.ClientSize.Height / 9;
            }
            //存储打乱后的图片数量
            List<Pic> list = new List<Pic>();
            //打乱一个大小根据难度动态变化的数组
            int[] array;
            if (DifficultyLevel == 1)
            {
                array = new int[9];
                array = Enumerable.Range(0, 9).OrderBy(n => random.Next()).ToArray<int>();//数组由0-8随即组成
                for (int i = 0; i < array.Length / 3; i++)
                {
                    Bitmap PicBackground = GetEBitmap(i);
                    for (int j = 0; j < 3; j++)
                    {
                        var p = new Pic { bitmap = PicBackground, index = array[i * 3 + j] };
                        list.Add(p);
                    }
                }
            }
            else if(DifficultyLevel == 3)
            {
                array = new int[81];
                array = Enumerable.Range(0, 81).OrderBy(n => random.Next()).ToArray<int>();
                for (int i = 0; i < array.Length / 3; i++)
                {
                    Bitmap PicBackground = GetBitmap();
                    for (int j = 0; j < 3; j++)
                    {
                        var p = new Pic { bitmap = PicBackground, index = array[i * 3 + j] };
                        list.Add(p);
                    }
                }
            }
            else
            {
                array = new int[324];
                array = Enumerable.Range(0, 324).OrderBy(n => random.Next()).ToArray<int>();
                for (int i = 0; i < array.Length / 3; i++)
                {
                    Bitmap PicBackground = GetBitmap();
                    for (int j = 0; j < 3; j++)
                    {
                        var p = new Pic { bitmap = PicBackground, index = array[i * 3 + j] };
                        list.Add(p);
                    }
                }
            }
            //排序list1用来打乱元素
            var plist = list.OrderBy(x => x.index).ToArray();
            //根据pailist1来排列图片
            for (int i = 0; i < 9; i++)
            {
                int offsetX = random.Next(-10, 200);
                int offsetY = random.Next(-10, 200);

                for (int x = 0; x < DifficultyLevel; x++)
                {
                    for (int y = 0; y < DifficultyLevel; y++)
                    {
                        Button but = new Button();
                        but.Location = new System.Drawing.Point(centerX - 10 + 50 * x + offsetX, centerY - 10 + 50 * y + offsetY);
                        but.Size = new System.Drawing.Size(width: 50, height: 50);
                        //根据难度选择图片
                        if (DifficultyLevel == 1)
                        {
                            but.Image = plist[i + x + y].bitmap;
                        }
                        else if (DifficultyLevel == 3)
                        {
                            but.Image = plist[i * 9 + x * 3 + y].bitmap;
                        }
                        else
                        {
                            but.Image = plist[i * 36 + x * 6 + y].bitmap;
                        }
                        but.TabIndex = PicCount;
                        this.Controls.Add(but);
                        PicCount++;
                        //给图片加上按钮方法
                        but.Click += new EventHandler(Button_Click);
                    }
                }
            }
            Overlap();

            this.UpdateStyles();
        }
        private async void Button_Click(object sender, EventArgs e)
        {
            // 播放点击音效
            clickSound.Play();

            Button clickedButton = (Button)sender;

            // 更新 lastClickedImageInfo
            lastClickedImageInfo = new LastPic
            {
                Loc = clickedButton.Location,
                IsAddedToPanel = true,
            };
            movePic = new MovePic();
            movePic.btn = new Button();
            movePic.btn = clickedButton;
            Move();
            await Task.Delay(800); // 等待
            
                AddPic(clickedButton);

                this.Controls.Remove(clickedButton);//桌面移除图片

                Overlap();

                ClickedPicCount++; // 点击的图片数量增加

                if (ClickedPicCount == PicCount) // 当点击的图片数量等于总图片数量时，游戏成功
                {
                    Timer_clock.Stop();
                    MessageBox.Show("游戏成功！泰裤辣！\n");
                    MessageBox.Show("刷新次数为" + RefreshNum + "次" + "   撤回次数为" + WithdrawNum + "次");
                    if (ElapsedSeconds < 60)
                    {
                        MessageBox.Show("用时:" + ElapsedSeconds + "秒");
                    }
                    else if (ElapsedSeconds < 3600)
                    {
                        MessageBox.Show("用时:" + ElapsedSeconds / 60 + "分" + (ElapsedSeconds - (ElapsedSeconds / 60) * 60) + "秒");
                    }
                    ClientFormSet.WindowState = FormWindowState.Normal;
                    this.Close();
                }
        }
        private void Btnback_Click(object sender, EventArgs e)
        {
            ClientFormSet.WindowState = FormWindowState.Normal;
            this.Close();
        }
        
        private void Timerclock_Tick(object sender, EventArgs e)
        {
            // 每次计时器间隔触发时更新已经过去的秒数并更新 UI
            ElapsedSeconds++;
            if (ElapsedSeconds < 60)
            {
                Label_clock.Text = "已用时间：" + ElapsedSeconds + " 秒";
            }
            else if(ElapsedSeconds < 3600)
            {
                Label_clock.Text = "已用时间：" + ElapsedSeconds / 60 + " 分"+ (ElapsedSeconds - (ElapsedSeconds / 60)*60) + " 秒";
            }
        }
        private void Timermove_Tick(object sender, EventArgs e)
        {
            int x = (int)Math.Round(movePic.btn.Location.X - movePic.DistanceX * t); // 计算按钮的新X坐标
            int y = (int)Math.Round(movePic.btn.Location.Y - movePic.DistanceY * t); // 计算按钮的新Y坐标
            movePic.btn.Location = new Point(x, y); // 更新按钮的位置*/

            if (movePic.btn.Location.Y>=  panel.Location.Y-10) // 如果动画结束
            {
                movePic = null;
                Timer_move.Stop(); // 停止计时器
            }
        }
        private bool isPlaying = true; // 用于记录播放和暂停
        private void Picmusic_Click(object sender, EventArgs e)
        {
            if (isPlaying)
            {
                bgm.Stop();
                isPlaying = false;
                Pic_music.Image = Properties.Resources.zanting;
            }
            else
            {
                bgm.PlayLooping();
                isPlaying = true;
                Pic_music.Image = Properties.Resources.bofang;
            }
        }

    }
}